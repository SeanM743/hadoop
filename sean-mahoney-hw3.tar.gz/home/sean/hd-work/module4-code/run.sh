java -cp `hadoop classpath`:target/module4-code-1.0-SNAPSHOT.jar edu.jhu.bdpuh.hdfs.ParallelLocalToHdfsCopy $@
