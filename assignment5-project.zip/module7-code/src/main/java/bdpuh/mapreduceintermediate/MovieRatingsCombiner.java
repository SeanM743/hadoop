package bdpuh.mapreduceintermediate;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MovieRatingsCombiner extends Reducer<Text, Text, Text, Text> {
    
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
     
        Text word = new Text();
        int total = 0;
        int ratings = 0;

        for (Text val : values) {
            String parts[] = val.toString().split("\t");
            if (parts[0].equals("data")){
                ratings += Integer.parseInt(parts[1]);
                total += Integer.parseInt(parts[2]);
            }
            else{
                context.write(key, new Text("item\t" + parts[1] + "\t" + parts[2] + "\t" + parts[3])); //movie id and title
                return;
            }       
        }
        word.set(key);
        context.write(word, new Text("data\t" + total + "\t" + ratings));             
    }
}   
