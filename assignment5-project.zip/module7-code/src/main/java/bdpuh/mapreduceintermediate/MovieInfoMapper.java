package bdpuh.mapreduceintermediate;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;
import org.apache.hadoop.mapreduce.Counter;

public class MovieInfoMapper extends Mapper<LongWritable, Text, Text, Text>{ 
    
    Logger logger = Logger.getLogger(MovieInfoMapper.class);
    IntWritable one = new IntWritable(1);
    Text word = new Text();

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        super.setup(context);
        logger.info("in setup of " + context.getTaskAttemptID().toString());
        // String fileName = ((FileSplit) context.getInputSplit()).getPath() + "";
        // System.out.println ("in stdout "+ context.getTaskAttemptID().toString() + " " +  fileName);
        // System.err.println ("in stderr "+ context.getTaskAttemptID().toString());
    }
    
    
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String lines[] = line.split("\\|+");
        word.set(lines[0]);
        context.write(word, new Text("item\t" + lines[1] + "\t" + lines[2] + "\t" + lines[3])); //movie id and title
        //System.out.println("item\t" + lines[1] + "\t" + lines[2] + "\t" + lines[3]);
        Counter counter = context.getCounter("MyCounter", "TOTAL_INFO_MAPS");
        counter.increment(1);

    }   
}
