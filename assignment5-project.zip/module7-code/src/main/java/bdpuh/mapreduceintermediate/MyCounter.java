package bdpuh.mapreduceintermediate;

public enum MyCounter{
    UNIQUE_WORDS, TOTAL_RATING_MAPS, TOTAL_INFO_MAPS
}
