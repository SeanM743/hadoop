package bdpuh.mapreduceintermediate;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Counter;

public class MovieReducerWithCombiner extends Reducer<Text, Text, Text, Text> {
    
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
     
        int count = 0;
        int total = 0;
        String name = "";
        String movieId = "";
        String date = "";
        String title = "";

        for (Text val : values) {
            String parts[] = val.toString().split("\t");
            if (parts[0].equals("data")){
                count += Integer.parseInt(parts[1]);
                total += Integer.parseInt(parts[2]);
            }else if (parts[0].equals("item")){
                name = parts[1];
                date = parts[2];
                movieId = key.toString();
                title = parts[3];
            }
              
        }
        double rating_average = (double)total / count;
        String str = String.format("%s\t%d\t%d\t%.02f\t%s\t%s", movieId, count,  total, rating_average, date, title);
        context.write(new Text(name), new Text(str));
        Counter counter = context.getCounter("MyCounter", "UNIQUE_WORDS");
        counter.increment(1);
        
    }   
}
