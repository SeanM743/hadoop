package bdpuh.mapreduceintermediate;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Counter;

public class MovieRatingsJob {
    public static void main(String args[]) throws Exception  {
        Job movieRatings = null;
        
        Configuration conf = new Configuration();
        conf.addResource(new Path("/usr/local/hadoop/hadoop-3.2.0/etc/hadoop/core-site.xml"));
        conf.addResource(new Path("/usr/local/hadoop/hadoop-3.2.0/etc/hadoop/hdfs-site.xml"));

        // Job Input Compression, Default value works 
        // Set only if you have specialized codec       
        conf.setStrings("io.compression.codecs", "org.apache.hadoop.io.compress.GzipCodec");
        
        // Job Output Compression
        conf.setBoolean("mapred.output.compress", true);
        conf.setStrings("mapred.output.compression.codec", "org.apache.hadoop.io.compress.GzipCodec");
        
        //Intermediate Mapper/Reducer Compression
        //conf.setBoolean("mapred.compress.map.output", true);
        //conf.setStrings("mapred.map.output.compression.codec", "org.apache.hadoop.io.compress.GzipCodec");
       
        
        try {
            movieRatings = Job.getInstance(conf, "rating count");
            } catch (IOException ex) {
            Logger.getLogger(MovieRatingsJob.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        movieRatings.setReducerClass(MovieReducerWithCombiner.class);
        movieRatings.setJarByClass(bdpuh.mapreduceintermediate.MovieRatingsJob.class);
        movieRatings.setOutputKeyClass(Text.class);
        movieRatings.setOutputValueClass(Text.class);
        MultipleInputs.addInputPath(movieRatings, new Path(args[0] + "/u.item"), TextInputFormat.class, MovieInfoMapper.class);
        MultipleInputs.addInputPath(movieRatings, new Path(args[0] + "/*.data"), TextInputFormat.class, MovieRatingsMapWithCombiner.class);
        movieRatings.setCombinerClass(MovieRatingsCombiner.class);
     
        
        // Set the Output path
        Path outputPath = new Path(args[1]);        
        FileOutputFormat.setOutputPath(movieRatings, outputPath);
        outputPath.getFileSystem(conf).delete(outputPath,true);
        
        movieRatings.setNumReduceTasks(2);             
        movieRatings.waitForCompletion(true);

        Counters cns = movieRatings.getCounters();
        Counter c1 = cns.findCounter("MyCounter","UNIQUE_WORDS");
        Counter c2 = cns.findCounter("MyCounter", "TOTAL_RATING_MAPS");
        Counter c3 = cns.findCounter("MyCounter", "TOTAL_INFO_MAPS");
        System.out.printf("There were %d unique movies.\n", c1.getValue());
        System.out.printf("There were %d rating map jobs.\n", c2.getValue());
        System.out.printf("There were %d movie information map jobs.\n", c3.getValue());
        

                
    }
    
}
