java -cp `yarn classpath`:target/module7-code-1.0-SNAPSHOT.jar bdpuh.mapreduceintermediate.MovieRatingsJob $@
