java -cp `hadoop classpath`:target/module6-code-1.0-SNAPSHOT.jar bdpuh.mapreducebasics.MovieDistribution movie-ratings movie-ratings-distribution @
