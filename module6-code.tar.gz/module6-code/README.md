Module 5 coding examples
This is a git repository with two branches: lecture and advanced
The lecture branch contains the code presented in the lecture as is
The advanced branch contains a slightly advanced version.

To access the code presented in the lecture follow these steps
$ git checkout lecture
$ mvn clean package
$ ./run.sh

To access the slightly advanced version, follow these steps. This advanced version is provided for reference only.
$ git checkout advanced
$ mvn clean package
$ ./run.sh
